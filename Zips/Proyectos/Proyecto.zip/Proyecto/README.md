# **Equipo Disp Moviles - Proyecto final** 😸📱🏭

- Carlos Emilio Castañón Maldonado  

- Neider Sánchez Reza

- Amir Gilberto Hidalgo Carrillo

[![](https://media.tenor.com/7_fyuUj-_BkAAAAC/bongo-cat.gif)](https://www.youtube.com/watch?v=btPJPFnesV4)

## **Uso**
Al ser una extensión de la tarea 3, el uso de esta aplicación es similar a la anteriormente mencionada:
- Dentro de la carpeta, ejecutar con Android Studio el Proyecto.
- La aplicacion esta pensada para dispositivos Android 5.0 en adelante.
- La aplicacion tiene como nombre Proyecto.

- Al ejecutarse la aplicacion se pediran los datos del usuario.
- Es **necesario** registrar un usuario en la pantalla de _Registro_ para guardarlo en la base de datos y poder iniciar sesión.
- Al ingresar los datos se puede navegar a través de las pantallas desde el menú _drawer_.
- La pantalla de perfil muestra información relevante del usuario, tomada desde la base de datos.
- La pantalla de adopción de gatos permite seleccionar un gato para adoptarlo.
