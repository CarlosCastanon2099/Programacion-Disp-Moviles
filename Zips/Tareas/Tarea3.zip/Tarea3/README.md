# **Equipo Disp Moviles - Tarea 3** 😸📱🏭

- Carlos Emilio Castañón Maldonado  

- Neider Sánchez Reza

- Amir Gilberto Hidalgo Carrillo

[![](https://media.tenor.com/U-vTBdF6z28AAAAd/cat-shaking.gif)](https://www.youtube.com/watch?v=KC6cPq-NmuU)

## **Uso**
Al ser una extensión de la tarea 2, el uso de esta aplicación es similar a la anteriormente mencionada:
- Dentro de la carpeta, ejecutar con Android Studio el Proyecto
- La aplicacion esta pensada para dispositivos Android 5.0 en adelante
- La aplicacion tiene como nombre Tarea3

- Al ejecutarse la aplicacion se pediran los datos del usuario 
- Al ingresar los datos se puede acceder a la siguiente pantalla mediante el boton <b> CONTINUAR </b>
- La siguiente pantalla muestra informacion relacionada con los Gatos, al oprimir el siguiente boton se redirecciona a una tercera pantalla donde se muestran varias fotos con gatos. :D
- Una vez que se han introducido los datos de acceso, se muestra el _navigation drawer_, el cual permite cambiar fácilmente entre pantallas.
