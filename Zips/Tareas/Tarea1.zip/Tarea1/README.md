# **Equipo Disp Moviles - Tarea 1** 🎮🥊

- Carlos Emilio Castañón Maldonado  

- Neider Sánchez Reza

- Amir Gilberto Hidalgo Carrillo

